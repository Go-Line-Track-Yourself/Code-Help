#ifndef VARS_HPP
#define VARS_HPP


#endif /* end of include guard: VARS_HPP */
