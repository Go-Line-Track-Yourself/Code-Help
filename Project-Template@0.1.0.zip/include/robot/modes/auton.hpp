//mode call stack
//auton task