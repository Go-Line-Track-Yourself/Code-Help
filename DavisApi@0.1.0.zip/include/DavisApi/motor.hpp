#pragma once
namespace G
{
    void test();
} // namespace G
